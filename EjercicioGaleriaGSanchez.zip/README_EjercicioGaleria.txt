
En el presente proyecto, se destaca la accion de pulsar el boton, abrir galeria y pasar los bitmaps a la app desde donde se pulsó el botón, 
Para ello es necesario que:

- Para escoger la imagen, abra galeria o google (photos - fotos(depende del idioma de su dispositivo)), ya que solo en esas dos opciones 
	se pueden extraer las fotos
- De preferencia se recomienda en el caso de no tener imagenes en la galeria, descargar constatar que se encuentran en cualquiera de las galerias antes mencionadas
 